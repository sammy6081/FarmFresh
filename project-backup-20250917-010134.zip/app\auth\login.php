﻿<?php require "../includes/header.php";?>
<?php require "../config/config.php";?>
<?php
    // if (isset($_SESSION['username'])) {
    //     header("Location:".APPURL."index.php");
    //     exit;
    // }
?>

<?php
if(isset($_POST["submit"])){
    if(empty($_POST['email']) OR empty($_POST['password'])) {
        echo "one or more inputs are empty";
    } else {
        $email = trim($_POST['email']);
        $password = $_POST['password'];

        // Safe prepared statement + error logging
        try {
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
            $stmt->execute([':email' => $email]);
            $fetch = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log('Login query error: ' . $e->getMessage());
            die('An internal error occurred. Check container logs for details.');
        }

        // validate username
        if ($fetch && count($fetch) > 0) {
            // validate password
            if (password_verify($password, $fetch['mypassword'])) {
                // set session values
                $_SESSION['username'] = $fetch['username'];
                $_SESSION['email'] = $fetch['email'];
                $_SESSION['user_id'] = $fetch['id'];
                $_SESSION['image'] = $fetch['image'];

                echo "<script> window.location.href='".APPURL."'; </script>";
                exit;
            } else {
                echo "<script> alert('email or password is wrong')</script>";
            }
        } else {
            echo "<script> alert('email or password is wrong')</script>";
        }
    }
}
?>

<div id="page-content" class="page-content">
    <div class="banner">
        <div class="jumbotron jumbotron-bg text-center rounded-0" style="background: linear-gradient(rgba(255,192,203,0.3), rgba(255,192,203,0.3)), url('<?php echo APPURL; ?>assets/img/bg-header.png'); background-size: cover; background-position: center;">
            <div class="container">
                <h1 class="pt-5">Login Page</h1>
                <p class="lead">Save time and leave the groceries to us.</p>

                <div class="card card-login mb-5">
                    <div class="card-body">
                        <form class="form-horizontal" method="POST" action="<?php echo APPURL; ?>auth/login.php">
                            <div class="form-group row mt-3">
                                <div class="col-md-12">
                                    <input class="form-control" name="email" type="text" required="" placeholder="Email">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input class="form-control" name="password" type="password" required="" placeholder="Password">
                                </div>
                            </div>
                            <div class="form-group row text-center mt-4">
                                <div class="col-md-12">
                                    <button name="submit" type="submit" class="btn btn-primary btn-block text-uppercase">Log In</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php require "../includes/footer.php";?>


