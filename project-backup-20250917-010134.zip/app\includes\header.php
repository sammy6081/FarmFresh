﻿<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) { session_start(); }
define("APPURL","http://localhost:8080/");
define("IMGCATEGORY", APPURL . "admin-panel/Categories-admins/img_category/");
define("IMGPRODUCT", APPURL . "admin-panel/products-admins/img_product/");

require dirname(dirname(__FILE__))."/config/config.php";

if(isset($_SESSION['user_id'])){
    $cart = $conn->query("SELECT COUNT(*) as num_products FROM cart WHERE user_id='$_SESSION[user_id]'");
    $cart->execute();

    $num = $cart->fetch(PDO::FETCH_OBJ);
}
?>
